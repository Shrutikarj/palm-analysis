"""
line_detection.py
-----------------
Detects palm lines (heart line, head line, life line) using:
  - Canny Edge Detection  (primary method)
  - Probabilistic Hough Transform (enhancement layer)

The module returns annotated images at each stage and raw line data
for feature extraction.
"""

import cv2
import numpy as np


def detect_edges(blurred_gray: np.ndarray) -> np.ndarray:
    """
    Apply Canny edge detection to a blurred grayscale image.

    Uses a dual-strategy threshold selection:
      1. Otsu-based (works well for high-contrast real palm photos)
      2. Percentile-based fallback for low-variance images (synthetic / pale skin)

    Args:
        blurred_gray: Single-channel, pre-blurred image.

    Returns:
        edges: Binary edge map (uint8).
    """
    # Strategy 1: Otsu thresholds
    otsu_thresh, _ = cv2.threshold(
        blurred_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    low_otsu  = max(0,   int(otsu_thresh * 0.4))
    high_otsu = min(255, int(otsu_thresh * 1.2))

    edges = cv2.Canny(blurred_gray, low_otsu, high_otsu,
                      apertureSize=3, L2gradient=True)

    # Strategy 2: if Otsu yields too few edges (low-contrast image),
    # fall back to percentile-based thresholds
    if np.count_nonzero(edges) < 100:
        median = float(np.median(blurred_gray))
        low  = max(0,   int(max(0, (1.0 - 0.33) * median)))
        high = min(255, int(min(255, (1.0 + 0.33) * median)))
        # Additional fallback: fixed low thresholds
        low  = min(low,  20)
        high = min(high, 60)
        edges = cv2.Canny(blurred_gray, low, high,
                          apertureSize=3, L2gradient=True)

    # Morphological closing to connect fragmented edge segments
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=1)

    return edges


def detect_lines_hough(edges: np.ndarray, original_bgr: np.ndarray) -> dict:
    """
    Run Probabilistic Hough Transform on the edge map to find line segments.

    Args:
        edges       : Binary edge image from detect_edges().
        original_bgr: BGR palm crop on which to draw results.

    Returns:
        dict: {
            'line_image' : BGR image with detected lines drawn,
            'lines'      : list of (x1,y1,x2,y2) tuples,
            'count'      : number of lines found
        }
    """
    h, w = edges.shape[:2]
    min_line_len = max(20, int(min(h, w) * 0.15))  # adaptive minimum length

    raw_lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=25,
        minLineLength=min_line_len,
        maxLineGap=12,
    )

    line_image = original_bgr.copy()
    lines = []

    if raw_lines is not None:
        for seg in raw_lines:
            x1, y1, x2, y2 = seg[0]
            lines.append((x1, y1, x2, y2))
            cv2.line(line_image, (x1, y1), (x2, y2), (0, 200, 255), 2)

    return {
        "line_image": line_image,
        "lines": lines,
        "count": len(lines),
    }


def classify_palm_lines(
    lines: list, palm_height: int, palm_width: int
) -> dict:
    """
    Heuristically group detected line segments into the three classical
    palm lines based on their vertical position within the palm crop.

    Classification rules (approximate anatomy):
        - Heart line  : top 33 % of palm
        - Head line   : middle 33 %
        - Life line   : bottom 33 % (curves along thumb side)

    NOTE: This is purely rule-based geometry — NOT palmistry or prediction.

    Args:
        lines       : list of (x1,y1,x2,y2) tuples.
        palm_height : height of the palm ROI in pixels.
        palm_width  : width  of the palm ROI in pixels.

    Returns:
        dict mapping line name → list of (x1,y1,x2,y2) segments.
    """
    third = palm_height / 3.0

    classified = {
        "Heart Line": [],
        "Head Line": [],
        "Life Line": [],
    }

    for x1, y1, x2, y2 in lines:
        mid_y = (y1 + y2) / 2.0
        length = np.hypot(x2 - x1, y2 - y1)
        if length < 10:
            continue  # ignore tiny segments

        if mid_y < third:
            classified["Heart Line"].append((x1, y1, x2, y2))
        elif mid_y < 2 * third:
            classified["Head Line"].append((x1, y1, x2, y2))
        else:
            classified["Life Line"].append((x1, y1, x2, y2))

    return classified


def draw_classified_lines(
    original_bgr: np.ndarray, classified: dict
) -> np.ndarray:
    """
    Draw classified palm lines in distinct colours on the palm image.

    Colour scheme:
        Heart Line → Red
        Head  Line → Green
        Life  Line → Blue

    Returns:
        BGR annotated image.
    """
    colour_map = {
        "Heart Line": (80, 80, 255),   # Red-ish
        "Head Line":  (80, 220, 80),   # Green-ish
        "Life Line":  (255, 160, 60),  # Blue-ish (orange in BGR)
    }
    label_offset = {"Heart Line": -10, "Head Line": 0, "Life Line": 10}

    annotated = original_bgr.copy()

    for line_name, segments in classified.items():
        colour = colour_map.get(line_name, (200, 200, 200))
        for x1, y1, x2, y2 in segments:
            cv2.line(annotated, (x1, y1), (x2, y2), colour, 2)

        if segments:
            # Label near the first segment's midpoint
            x1, y1, x2, y2 = segments[0]
            mx, my = (x1 + x2) // 2, (y1 + y2) // 2 + label_offset[line_name]
            cv2.putText(
                annotated,
                line_name,
                (mx, my),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                colour,
                1,
                cv2.LINE_AA,
            )

    return annotated
