"""
hand_detection.py
-----------------
Public API for hand landmark detection.

Uses MediaPipe's TFLite models (palm_detection_lite.tflite +
hand_landmark_lite.tflite) via TensorFlow Lite — fully offline,
no external model download required at runtime.

Exports
-------
detect_landmarks(image_bgr)  →  dict
get_landmark_names()         →  dict[int, str]
"""

from tflite_hand_detector import detect_landmarks, get_landmark_names  # noqa: F401

__all__ = ["detect_landmarks", "get_landmark_names"]
