"""
setup.py
--------
One-time setup script for PalmCV.

Run ONCE before starting app.py:
    python setup.py

Actions
-------
1. Downloads MediaPipe TFLite models from the mediapipe PyPI wheel
   (palm_detection_lite.tflite + hand_landmark_lite.tflite) — no Google
   Cloud Storage required.
2. Generates the demo synthetic palm image used by the /demo route.
3. Verifies the full import chain works correctly.
"""

import os
import sys
import io
import zipfile
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))


# ── 1. Download TFLite models ──────────────────────────────────────────────────

MODELS = {
    "palm_detection_lite.tflite":
        "mediapipe/modules/palm_detection/palm_detection_lite.tflite",
    "hand_landmark_lite.tflite":
        "mediapipe/modules/hand_landmark/hand_landmark_lite.tflite",
}


def download_models():
    """Pull TFLite models from the mediapipe PyPI wheel (pythonhosted.org)."""
    needed = [m for m in MODELS if not os.path.exists(os.path.join(HERE, m))]
    if not needed:
        print("✓ TFLite models already present — skipping download.")
        return

    print("Fetching model list from PyPI…")
    import json
    with urllib.request.urlopen("https://pypi.org/pypi/mediapipe/json", timeout=15) as r:
        meta = json.loads(r.read())

    # Pick the smallest Linux x86_64 wheel
    wheel_url = None
    for u in meta["urls"]:
        if "linux" in u["filename"] and "x86_64" in u["filename"]:
            wheel_url = u["url"]
            break

    if not wheel_url:
        # Fallback: pick any wheel (Windows / macOS) — models are platform-independent
        wheel_url = meta["urls"][0]["url"]

    print(f"Downloading mediapipe wheel ({meta['info']['version']}) …")
    with urllib.request.urlopen(wheel_url, timeout=120) as r:
        whl_bytes = r.read()
    print(f"  Got {len(whl_bytes)/1e6:.1f} MB")

    with zipfile.ZipFile(io.BytesIO(whl_bytes)) as z:
        for dest_name, src_path in MODELS.items():
            if dest_name not in needed:
                continue
            try:
                content = z.read(src_path)
                dest = os.path.join(HERE, dest_name)
                with open(dest, "wb") as f:
                    f.write(content)
                print(f"  ✓ Extracted {dest_name}  ({len(content)/1e6:.2f} MB)")
            except KeyError:
                print(f"  ✗ {src_path} not found in wheel — trying alternate path…")
                # Some wheel versions put models under a different prefix
                for name in z.namelist():
                    if dest_name in name:
                        content = z.read(name)
                        dest = os.path.join(HERE, dest_name)
                        with open(dest, "wb") as f:
                            f.write(content)
                        print(f"    ✓ Found as {name}")
                        break


# ── 2. Generate demo image ─────────────────────────────────────────────────────

def generate_demo():
    """Create a synthetic palm image used by /demo route."""
    demo_path = os.path.join(HERE, "static", "uploads", "demo_hand.jpg")
    os.makedirs(os.path.dirname(demo_path), exist_ok=True)

    if os.path.exists(demo_path):
        print("✓ Demo image already exists — skipping.")
        return

    import numpy as np
    import cv2

    W, H = 640, 480
    img = np.full((H, W, 3), (215, 205, 198), dtype=np.uint8)

    skin_mid  = np.array([130, 175, 215], dtype=np.float32)
    skin_edge = np.array([110, 155, 195], dtype=np.float32)

    for r in range(130, 0, -1):
        t = r / 130.0
        col = tuple(int(c) for c in (skin_mid * (1 - t) + skin_edge * t))
        cv2.ellipse(img, (320, 285), (r, int(r * 1.18)), 0, 0, 360, col, 1)

    configs = [
        ((218, 122), (228, 182), 16),
        ((258,  92), (264, 167), 15),
        ((308,  80), (310, 162), 15),
        ((358,  92), (356, 167), 15),
        ((398, 142), (388, 182), 14),
    ]
    for tip, base, hw in configs:
        pts = np.array([
            (base[0] - hw, base[1]), (tip[0] - hw + 2, tip[1]),
            (tip[0] + hw - 2, tip[1]), (base[0] + hw, base[1]),
        ], np.int32)
        cv2.fillPoly(img, [pts], (125, 170, 210))
        cv2.polylines(img, [pts], True, (105, 150, 190), 2)

    crease = (85, 125, 160)
    cv2.line(img, (228, 228), (398, 218), crease, 3)
    cv2.line(img, (233, 268), (393, 258), crease, 3)
    life_pts = np.array([(243, 308), (238, 340), (234, 370), (232, 392)], np.int32)
    cv2.polylines(img, [life_pts], False, crease, 3)

    rng = np.random.default_rng(42)
    noise = rng.integers(-8, 8, img.shape, dtype=np.int8).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    cv2.imwrite(demo_path, img)
    print(f"✓ Demo image saved → {demo_path}")


# ── 3. Verify imports ──────────────────────────────────────────────────────────

def verify():
    print("\nVerifying imports…")
    try:
        from hand_detection import detect_landmarks, get_landmark_names
        from palm_extraction import extract_palm_roi, preprocess_palm
        from line_detection import detect_edges, detect_lines_hough
        from feature_analysis import analyse_all_lines, build_summary
        print("  ✓ All modules OK")
        print(f"  ✓ Landmark 0 = {get_landmark_names()[0]}")
    except Exception as e:
        print(f"  ✗ Import error: {e}")
        sys.exit(1)


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "=" * 55)
    print("  PalmCV Setup")
    print("=" * 55)

    download_models()
    generate_demo()
    verify()

    print("\n" + "=" * 55)
    print("  Setup complete!")
    print("  Run:  python app.py")
    print("  Open: http://127.0.0.1:5000")
    print("=" * 55 + "\n")
