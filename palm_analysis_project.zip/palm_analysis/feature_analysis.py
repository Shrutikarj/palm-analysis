"""
feature_analysis.py
-------------------
Extracts geometric features from detected palm lines:
  - Total length (sum of segment lengths)
  - Average angle / orientation
  - Estimated curvature (variance of segment angles in a group)
  - Bounding-box position (top, centre_y)
  - Segment count per line

All interpretations are rule-based heuristics for educational purposes only.
No claim is made about palmistry accuracy or future prediction.
"""

import numpy as np
from typing import Dict, List, Tuple


# ──────────────────────────────────────────────────────────────────────────────
# Low-level geometry helpers
# ──────────────────────────────────────────────────────────────────────────────

def segment_length(x1: int, y1: int, x2: int, y2: int) -> float:
    """Euclidean length of a line segment."""
    return float(np.hypot(x2 - x1, y2 - y1))


def segment_angle_deg(x1: int, y1: int, x2: int, y2: int) -> float:
    """
    Angle of a segment in degrees, measured from the positive x-axis.
    Returns value in [−180, 180].
    """
    return float(np.degrees(np.arctan2(y2 - y1, x2 - x1)))


def curvature_estimate(segments: list) -> float:
    """
    Estimate curvature as the circular standard deviation of segment angles.
    A straight line → low value; a curved/wavy line → high value.

    Args:
        segments: list of (x1,y1,x2,y2) tuples.

    Returns:
        Circular std deviation in degrees (0 = perfectly straight).
    """
    if len(segments) < 2:
        return 0.0
    angles_rad = np.array(
        [np.arctan2(y2 - y1, x2 - x1) for x1, y1, x2, y2 in segments]
    )
    # Circular mean
    mean_sin = np.mean(np.sin(angles_rad))
    mean_cos = np.mean(np.cos(angles_rad))
    R = np.hypot(mean_sin, mean_cos)  # resultant length [0,1]
    # Circular std ≈ sqrt(−2 ln R)
    if R >= 1.0:
        return 0.0
    return float(np.degrees(np.sqrt(-2.0 * np.log(R))))


# ──────────────────────────────────────────────────────────────────────────────
# Per-line feature extraction
# ──────────────────────────────────────────────────────────────────────────────

def extract_line_features(name: str, segments: list, palm_h: int, palm_w: int) -> dict:
    """
    Compute geometric features for one classified palm line.

    Args:
        name     : e.g. 'Heart Line'
        segments : list of (x1,y1,x2,y2)
        palm_h   : palm ROI height in pixels
        palm_w   : palm ROI width  in pixels

    Returns:
        dict with numeric features and a text description.
    """
    if not segments:
        return {
            "name": name,
            "segment_count": 0,
            "total_length_px": 0,
            "avg_angle_deg": None,
            "curvature_deg": 0.0,
            "top_y": None,
            "centre_y": None,
            "description": "Not detected in this image.",
        }

    lengths = [segment_length(*s) for s in segments]
    angles = [segment_angle_deg(*s) for s in segments]
    all_y = [y for _, y1, _, y2 in segments for y in (y1, y2)]

    total_len = sum(lengths)
    avg_angle = float(np.mean(angles))
    curv = curvature_estimate(segments)
    top_y = min(all_y)
    centre_y = float(np.mean(all_y))

    # Normalise position as fraction of palm height
    pos_frac = centre_y / palm_h if palm_h > 0 else 0.0

    # Generate a plain-language description (rule-based, NOT prediction)
    desc_parts = []
    if total_len > palm_w * 0.6:
        desc_parts.append("long, well-defined")
    elif total_len > palm_w * 0.3:
        desc_parts.append("medium length")
    else:
        desc_parts.append("short or fragmented")

    if curv < 10:
        desc_parts.append("relatively straight")
    elif curv < 25:
        desc_parts.append("gently curved")
    else:
        desc_parts.append("highly curved / wavy")

    description = f"{name}: {', '.join(desc_parts)}. " \
                  f"Total length ≈ {total_len:.0f} px across {len(segments)} segment(s)."

    return {
        "name": name,
        "segment_count": len(segments),
        "total_length_px": round(total_len, 1),
        "avg_angle_deg": round(avg_angle, 1),
        "curvature_deg": round(curv, 1),
        "top_y": top_y,
        "centre_y": round(centre_y, 1),
        "position_fraction": round(pos_frac, 3),
        "description": description,
    }


def analyse_all_lines(classified: dict, palm_h: int, palm_w: int) -> list:
    """
    Extract features for all three classified palm lines.

    Args:
        classified : dict from line_detection.classify_palm_lines()
        palm_h / w : palm ROI dimensions

    Returns:
        list of feature dicts (one per line type).
    """
    results = []
    for name, segments in classified.items():
        results.append(extract_line_features(name, segments, palm_h, palm_w))
    return results


def build_summary(features: list) -> str:
    """
    Build a human-readable summary paragraph from feature dicts.

    IMPORTANT: The summary is a geometric description only.
    It makes NO claims about personality, health, or future events.
    """
    lines = [
        "═" * 55,
        " PALM LINE ANALYSIS SUMMARY (Geometric / CV Only) ",
        "═" * 55,
        "(This is a computer-vision feature extraction result.",
        " No palmistry predictions are made or implied.)",
        "",
    ]
    for f in features:
        lines.append(f"▸ {f['description']}")
    lines += [
        "",
        f"Total line segments detected: "
        f"{sum(f['segment_count'] for f in features)}",
    ]
    return "\n".join(lines)
