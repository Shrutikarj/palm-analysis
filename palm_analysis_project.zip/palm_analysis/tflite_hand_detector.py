"""
tflite_hand_detector.py
-----------------------
Full hand-landmark detection using MediaPipe's TFLite models directly
(palm_detection_lite.tflite + hand_landmark_lite.tflite).

Pipeline
--------
1. Palm detection  → bounding box anchor + score
2. ROI crop        → 224×224 patch aligned to detected palm
3. Hand landmark   → 21 × (x,y,z) landmarks in crop space → map back to image

No internet required. Models are extracted from the mediapipe 0.10.5 wheel.
"""

import os
import math
import warnings
import numpy as np
import cv2

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
warnings.filterwarnings("ignore")

import tensorflow as tf  # noqa: E402

# ── Paths ─────────────────────────────────────────────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
PALM_MODEL_PATH = os.path.join(_HERE, "palm_detection_lite.tflite")
HAND_MODEL_PATH = os.path.join(_HERE, "hand_landmark_lite.tflite")

# MediaPipe palm detection anchors (192×192 input)
# Anchor config: 2 anchors at strides 8 and 16
_PALM_IN = 192
_HAND_IN = 224


# ── Anchor generation (matches MediaPipe BlazePalm config) ───────────────────

def _generate_anchors(input_size=192):
    """Generate SSD anchors for the palm detection model."""
    anchors = []
    strides = [8, 16, 16, 16]
    aspect_ratios = [1.0]
    anchor_offset_x = 0.5
    anchor_offset_y = 0.5
    interpolated_scale_aspect_ratio = 1.0

    for stride in strides:
        grid_rows = math.ceil(input_size / stride)
        grid_cols = math.ceil(input_size / stride)
        anchors_per_cell = 2  # BlazePalm uses 2 per location

        for r in range(grid_rows):
            for c in range(grid_cols):
                for _ in range(anchors_per_cell):
                    cx = (c + anchor_offset_x) / grid_cols
                    cy = (r + anchor_offset_y) / grid_rows
                    anchors.append([cx, cy, 1.0, 1.0])

    return np.array(anchors, dtype=np.float32)


_ANCHORS = _generate_anchors(_PALM_IN)  # shape (2016, 4)


# ── Model loaders (cached) ────────────────────────────────────────────────────

def _load_interpreter(path: str):
    interp = tf.lite.Interpreter(model_path=path)
    interp.allocate_tensors()
    return interp


_palm_interp = None
_hand_interp = None


def _get_palm_interp():
    global _palm_interp
    if _palm_interp is None:
        _palm_interp = _load_interpreter(PALM_MODEL_PATH)
    return _palm_interp


def _get_hand_interp():
    global _hand_interp
    if _hand_interp is None:
        _hand_interp = _load_interpreter(HAND_MODEL_PATH)
    return _hand_interp


# ── Pre/post processing helpers ───────────────────────────────────────────────

def _preprocess(img_bgr: np.ndarray, size: int) -> np.ndarray:
    """Resize + normalise BGR image to [-1, 1] float32 tensor."""
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    resized = cv2.resize(rgb, (size, size), interpolation=cv2.INTER_LINEAR)
    tensor = resized.astype(np.float32) / 127.5 - 1.0
    return np.expand_dims(tensor, 0)  # (1, size, size, 3)


def _decode_boxes(raw_boxes, anchors):
    """
    Decode SSD boxes from raw model output + anchors.
    raw_boxes: (N, 18)  — cx_off, cy_off, w, h, kp0x, kp0y … kp6x, kp6y
    anchors:   (N, 4)   — cx, cy, w, h (all in [0,1])
    Returns decoded boxes (N, 4) in [y1, x1, y2, x2] normalised.
    """
    boxes = np.zeros((raw_boxes.shape[0], 4), dtype=np.float32)
    cx = raw_boxes[:, 0] / _PALM_IN * anchors[:, 2] + anchors[:, 0]
    cy = raw_boxes[:, 1] / _PALM_IN * anchors[:, 3] + anchors[:, 1]
    w  = raw_boxes[:, 2] / _PALM_IN * anchors[:, 2]
    h  = raw_boxes[:, 3] / _PALM_IN * anchors[:, 3]
    boxes[:, 0] = cy - h / 2   # y1
    boxes[:, 1] = cx - w / 2   # x1
    boxes[:, 2] = cy + h / 2   # y2
    boxes[:, 3] = cx + w / 2   # x2
    return boxes


def _nms(boxes, scores, iou_thresh=0.3, score_thresh=0.5):
    """Simple greedy NMS. Returns best box index or -1."""
    valid = np.where(scores > score_thresh)[0]
    if len(valid) == 0:
        return -1, 0.0
    valid = valid[np.argsort(scores[valid])[::-1]]
    best = valid[0]
    return best, float(scores[best])


def _expand_box(box, img_h, img_w, scale=2.0):
    """
    Expand detected palm box by scale and square it to create
    a stable ROI for the hand landmark model.
    Returns (x1, y1, x2, y2) in pixel coordinates.
    """
    y1, x1, y2, x2 = box
    cx = (x1 + x2) / 2 * img_w
    cy = (y1 + y2) / 2 * img_h
    side = max((y2 - y1) * img_h, (x2 - x1) * img_w) * scale / 2

    px1 = max(0, int(cx - side))
    py1 = max(0, int(cy - side))
    px2 = min(img_w, int(cx + side))
    py2 = min(img_h, int(cy + side))
    return px1, py1, px2, py2


# ── Public API ─────────────────────────────────────────────────────────────────

def detect_landmarks(image_bgr: np.ndarray) -> dict:
    """
    Detect hand landmarks in a BGR image.

    Returns
    -------
    dict:
        success          : bool
        landmarks        : list of 21 (x_px, y_px) tuples in original image coords
        annotated_image  : BGR image with skeleton drawn
        confidence       : float — palm detection score
    """
    result = {
        "success": False,
        "landmarks": [],
        "annotated_image": image_bgr.copy(),
        "confidence": 0.0,
    }

    img_h, img_w = image_bgr.shape[:2]

    # ── Stage 1: Palm detection ───────────────────────────────────────────────
    palm_tensor = _preprocess(image_bgr, _PALM_IN)
    palm_interp = _get_palm_interp()
    inp_detail = palm_interp.get_input_details()[0]
    palm_interp.set_tensor(inp_detail["index"], palm_tensor)
    palm_interp.invoke()

    out_details = palm_interp.get_output_details()
    raw_boxes  = palm_interp.get_tensor(out_details[0]["index"])[0]  # (2016, 18)
    raw_scores = palm_interp.get_tensor(out_details[1]["index"])[0]  # (2016, 1)
    raw_scores = raw_scores[:, 0]

    # Sigmoid on scores
    scores = 1.0 / (1.0 + np.exp(-np.clip(raw_scores, -88, 88)))

    # Decode + NMS
    anchors_used = _ANCHORS[:len(raw_boxes)]
    decoded = _decode_boxes(raw_boxes, anchors_used)
    best_idx, conf = _nms(decoded, scores, score_thresh=0.5)

    if best_idx < 0:
        return result  # No palm detected

    result["confidence"] = conf
    best_box = decoded[best_idx]            # (y1,x1,y2,x2) normalised

    # ── Stage 2: Crop ROI and run hand landmark model ─────────────────────────
    px1, py1, px2, py2 = _expand_box(best_box, img_h, img_w, scale=2.0)

    # Safety: ensure non-zero crop
    if px2 - px1 < 10 or py2 - py1 < 10:
        return result

    crop = image_bgr[py1:py2, px1:px2]
    crop_h, crop_w = crop.shape[:2]

    hand_tensor = _preprocess(crop, _HAND_IN)
    hand_interp = _get_hand_interp()
    h_inp = hand_interp.get_input_details()[0]
    hand_interp.set_tensor(h_inp["index"], hand_tensor)
    hand_interp.invoke()

    h_out = hand_interp.get_output_details()
    # Identity: (1, 63)  — 21 landmarks × 3 (x,y,z) normalised to [0,1] in crop
    landmarks_raw = hand_interp.get_tensor(h_out[0]["index"])[0]  # (63,)
    hand_score    = float(hand_interp.get_tensor(h_out[1]["index"])[0][0])

    # Sigmoid on hand score
    hand_score = 1.0 / (1.0 + math.exp(-min(max(hand_score, -88), 88)))
    if hand_score < 0.5:
        return result

    # Reshape landmarks: (21, 3)
    lm = landmarks_raw.reshape(21, 3)

    # Map from crop-normalised → original pixel coords
    landmarks_px = []
    for i in range(21):
        x_px = int(lm[i, 0] / _HAND_IN * crop_w + px1)
        y_px = int(lm[i, 1] / _HAND_IN * crop_h + py1)
        # Clamp to image bounds
        x_px = max(0, min(img_w - 1, x_px))
        y_px = max(0, min(img_h - 1, y_px))
        landmarks_px.append((x_px, y_px))

    result["success"] = True
    result["landmarks"] = landmarks_px

    # ── Draw annotated skeleton ───────────────────────────────────────────────
    annotated = image_bgr.copy()
    _draw_hand_skeleton(annotated, landmarks_px)
    result["annotated_image"] = annotated

    return result


# MediaPipe hand connection pairs (21 landmarks)
_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),           # Thumb
    (0, 5), (5, 6), (6, 7), (7, 8),           # Index
    (0, 9), (9, 10), (10, 11), (11, 12),       # Middle
    (0, 13), (13, 14), (14, 15), (15, 16),     # Ring
    (0, 17), (17, 18), (18, 19), (19, 20),     # Pinky
    (5, 9), (9, 13), (13, 17),                 # Palm
]

_FINGER_COLOURS = {
    "thumb":  (255, 150,  50),
    "index":  ( 50, 200, 255),
    "middle": ( 50, 255, 150),
    "ring":   (200, 100, 255),
    "pinky":  (255,  80, 160),
    "palm":   (200, 200, 200),
}


def _draw_hand_skeleton(img: np.ndarray, lm: list) -> None:
    """Draw coloured hand skeleton on image in-place."""
    if len(lm) < 21:
        return

    colour_map = {}
    for i in range(1, 5):  colour_map[i] = _FINGER_COLOURS["thumb"]
    for i in range(5, 9):  colour_map[i] = _FINGER_COLOURS["index"]
    for i in range(9, 13): colour_map[i] = _FINGER_COLOURS["middle"]
    for i in range(13,17): colour_map[i] = _FINGER_COLOURS["ring"]
    for i in range(17,21): colour_map[i] = _FINGER_COLOURS["pinky"]
    colour_map[0] = _FINGER_COLOURS["palm"]

    for a, b in _CONNECTIONS:
        col = colour_map.get(b, (200, 200, 200))
        cv2.line(img, lm[a], lm[b], col, 2, cv2.LINE_AA)

    for idx, (x, y) in enumerate(lm):
        col = colour_map.get(idx, (200, 200, 200))
        cv2.circle(img, (x, y), 5, col, -1)
        cv2.circle(img, (x, y), 5, (255, 255, 255), 1)
        cv2.putText(img, str(idx), (x + 6, y - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.32, (255, 255, 0), 1, cv2.LINE_AA)


def get_landmark_names() -> dict:
    return {
        0: "WRIST",
        1: "THUMB_CMC", 2: "THUMB_MCP", 3: "THUMB_IP",  4: "THUMB_TIP",
        5: "INDEX_MCP", 6: "INDEX_PIP", 7: "INDEX_DIP",  8: "INDEX_TIP",
        9: "MIDDLE_MCP",10:"MIDDLE_PIP",11:"MIDDLE_DIP", 12:"MIDDLE_TIP",
        13:"RING_MCP",  14:"RING_PIP",  15:"RING_DIP",   16:"RING_TIP",
        17:"PINKY_MCP", 18:"PINKY_PIP", 19:"PINKY_DIP",  20:"PINKY_TIP",
    }
