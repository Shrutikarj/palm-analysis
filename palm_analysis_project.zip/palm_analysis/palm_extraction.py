"""
palm_extraction.py
------------------
Extracts the palm region of interest (ROI) from a full hand image using
MediaPipe landmark coordinates. Also applies image preprocessing steps
(grayscale → Gaussian blur → adaptive threshold) to prepare for line detection.
"""

import cv2
import numpy as np


# Landmark indices that define the palm boundary
# Wrist (0) + 4 MCP joints (5, 9, 13, 17) form a pentagon around the palm
PALM_LANDMARK_INDICES = [0, 1, 2, 5, 9, 13, 17]


def extract_palm_roi(image: np.ndarray, landmarks: list) -> dict:
    """
    Crop the palm region using a convex hull of selected landmarks.

    Args:
        image     : BGR image (full hand).
        landmarks : list of (x_px, y_px) for all 21 MediaPipe landmarks.

    Returns:
        dict: {
            'palm_roi'     : cropped BGR palm image,
            'mask_image'   : full-size mask showing the palm polygon,
            'bbox'         : (x, y, w, h) bounding box used for crop,
            'hull_points'  : convex hull vertices,
            'success'      : bool
        }
    """
    result = {
        "palm_roi": None,
        "mask_image": np.zeros_like(image),
        "bbox": None,
        "hull_points": None,
        "success": False,
    }

    if not landmarks or len(landmarks) < 21:
        return result

    # Select palm-boundary landmarks and compute convex hull
    palm_pts = np.array(
        [landmarks[i] for i in PALM_LANDMARK_INDICES], dtype=np.int32
    )
    hull = cv2.convexHull(palm_pts)
    result["hull_points"] = hull

    # Create a mask from the hull polygon
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    cv2.fillConvexPoly(mask, hull, 255)

    # Draw the hull on a visual copy
    mask_vis = image.copy()
    cv2.polylines(mask_vis, [hull], True, (0, 255, 0), 3)
    cv2.fillConvexPoly(mask_vis, hull, (0, 80, 0))  # semi-transparent tint
    cv2.addWeighted(mask_vis, 0.4, image, 0.6, 0, mask_vis)
    cv2.polylines(mask_vis, [hull], True, (0, 255, 0), 2)
    result["mask_image"] = mask_vis

    # Bounding box of the hull → crop
    x, y, w, h = cv2.boundingRect(hull)
    # Add a small padding
    pad = 15
    x1 = max(0, x - pad)
    y1 = max(0, y - pad)
    x2 = min(image.shape[1], x + w + pad)
    y2 = min(image.shape[0], y + h + pad)

    palm_crop = image[y1:y2, x1:x2]
    result["palm_roi"] = palm_crop
    result["bbox"] = (x1, y1, x2 - x1, y2 - y1)
    result["success"] = True

    return result


def preprocess_palm(palm_roi: np.ndarray) -> dict:
    """
    Apply a preprocessing pipeline to the palm ROI for line detection.

    Pipeline:
        1. Grayscale conversion
        2. Histogram equalisation (CLAHE) for contrast enhancement
        3. Gaussian blur to reduce noise
        4. Adaptive threshold → binary image

    Args:
        palm_roi : BGR cropped palm image.

    Returns:
        dict with keys: 'gray', 'equalized', 'blurred', 'thresh'
    """
    # 1. Grayscale
    gray = cv2.cvtColor(palm_roi, cv2.COLOR_BGR2GRAY)

    # 2. CLAHE for local contrast enhancement
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    equalized = clahe.apply(gray)

    # 3. Gaussian blur
    blurred = cv2.GaussianBlur(equalized, (5, 5), 0)

    # 4. Adaptive threshold
    thresh = cv2.adaptiveThreshold(
        blurred,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        blockSize=11,
        C=2,
    )

    return {
        "gray": gray,
        "equalized": equalized,
        "blurred": blurred,
        "thresh": thresh,
    }
