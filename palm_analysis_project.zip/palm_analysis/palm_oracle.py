"""
palm_oracle.py
--------------
🔮 Palm Oracle — Entertainment-Only Astrology Reading Engine

Generates fun, vivid "readings" for Career, Health, Love/Marriage, and
Success based purely on the geometric features already extracted from the
palm image (line lengths, curvature, segment counts, positions).

IMPORTANT DISCLAIMER
====================
Every reading produced here is ENTERTAINMENT ONLY — the digital equivalent
of a fortune cookie or horoscope.  The "predictions" are creative text
selected by rule-based thresholds on CV measurements.  They carry exactly
zero scientific validity.  No medical, financial, relationship, or life
advice is implied or should be inferred.
"""

import random
import math
from typing import Optional


# ── Seeded RNG so the same image always gets the same reading ─────────────────

def _rng(seed: int) -> random.Random:
    return random.Random(seed)


# ── Reading banks ─────────────────────────────────────────────────────────────
# Each bank is keyed by (strong | moderate | gentle | faint) strength tier.

CAREER = {
    "strong": [
        ("🌟 The Summit Seeker",
         "Your heart line blazes wide and true — the mark of someone who climbs "
         "with relentless purpose. Leadership roles, entrepreneurship, and bold "
         "creative ventures are written into your palm. Expect a significant "
         "professional turning point within the next cycle."),
        ("⚡ The Architect of Empires",
         "A deep, well-travelled heart line signals an extraordinary capacity "
         "for strategic thinking. You don't just build careers — you build "
         "legacies. Industries that reward vision: technology, finance, the arts."),
        ("🔥 The Trailblazer",
         "Rare double-depth lines converge at your palm's apex — ancient "
         "palmists called this the 'commander's cross'. Authority comes "
         "naturally; others instinctively follow your lead."),
    ],
    "moderate": [
        ("🌿 The Steady Climber",
         "Your lines show a career of meaningful, compounding progress. "
         "You may not sprint to the top, but every step is sure-footed. "
         "Collaborations formed in the coming season will prove pivotal."),
        ("🎯 The Specialist",
         "A moderately curved heart line favours depth over breadth. "
         "Mastery in a focused domain — science, craft, healing, teaching — "
         "will bring both recognition and personal fulfilment."),
        ("🌊 The Adaptive Talent",
         "Your palm's geometry suggests a career that shape-shifts beautifully "
         "across phases. What looks like detours are actually accelerations "
         "in disguise. Embrace the pivot."),
    ],
    "gentle": [
        ("🌱 The Late Bloomer",
         "Shorter, lighter lines often belong to those whose greatest work "
         "arrives when others have settled. Patience is your secret weapon; "
         "your most impactful chapter is still ahead."),
        ("🎨 The Creative Nomad",
         "Your lines speak of a career painted in many colours — multiple "
         "vocations, side projects, portfolio careers. Conventional ladders "
         "were never your style, and that's precisely your advantage."),
    ],
    "faint": [
        ("🌙 The Hidden Potential",
         "Subtle lines often hide extraordinary reserves. A period of "
         "introspection and skill-building is indicated — the quiet before "
         "an impressive breakthrough. Your story is far from written."),
    ],
}

HEALTH = {
    "strong": [
        ("💚 Vitality Ascending",
         "A long, deeply-etched life line arcing wide of the thumb is the "
         "classical sign of robust constitution. Your body's resilience is "
         "a gift — honour it with movement, rest, and nourishment and it "
         "will carry you powerfully through decades ahead."),
        ("🌞 The Iron Constitution",
         "Your life line's generous sweep suggests exceptional recuperative "
         "power. Even when life tests your endurance, you return stronger. "
         "Watch for an energy renaissance beginning this season."),
    ],
    "moderate": [
        ("🍃 Balanced Energy",
         "Moderate life-line depth suggests a body that responds well to "
         "routine and rhythm. Regular sleep, mindful eating, and short "
         "bursts of vigorous exercise will keep your vitality consistently high."),
        ("✨ The Mindful Vessel",
         "Your palm suggests the mind-body connection is particularly potent "
         "for you. Practices that calm the nervous system — breathwork, "
         "movement meditation, time in nature — will yield outsized returns."),
        ("🌿 Steady Reserves",
         "A gently traced life line belongs to those who pace themselves "
         "wisely. Your energy is reliable rather than volcanic — a sustainable "
         "flame that outlasts many brighter but shorter-burning sparks."),
    ],
    "gentle": [
        ("🌸 The Sensitive System",
         "Your lines hint at a constitution that benefits enormously from "
         "intentional care. Stress management and restorative sleep are not "
         "luxuries for you — they are your primary health tools."),
        ("🦋 The Transformer",
         "Lighter lines sometimes indicate a body mid-transformation — "
         "adapting, recalibrating, growing into a new energetic baseline. "
         "This is a season of healing that will compound into strength."),
    ],
    "faint": [
        ("🌙 Renewal on the Horizon",
         "The quieter your life line, the louder the invitation to slow down "
         "and listen to your body's whispers. Small, consistent acts of "
         "self-care now prevent larger corrections later."),
    ],
}

MARRIAGE = {
    "strong": [
        ("💖 The Great Love",
         "A sweeping, unbroken heart line curving high toward Jupiter's mount "
         "is the mark of someone who loves with magnificent depth. A profound "
         "partnership — built on intellectual fire and emotional safety — "
         "is strongly indicated. If you haven't found it, you are close."),
        ("🌹 Twin Flames",
         "Your heart line's bold arc tells of connections that transform. "
         "The person who truly sees you is either already in your orbit or "
         "approaching rapidly. Relationships for you are never superficial — "
         "they are life-altering."),
        ("💫 The Devoted Heart",
         "Long, curved, unbroken — your heart line speaks of lasting fidelity "
         "and a love that deepens with time rather than fading. Long-term "
         "partnership is both your nature and your destiny."),
    ],
    "moderate": [
        ("🌷 The Balanced Bond",
         "Your heart line suggests relationships built on mutual respect and "
         "shared purpose. You seek a partner who is also a best friend. "
         "The right connection will feel effortless — like coming home."),
        ("🌟 The Conscious Partner",
         "Moderate curvature indicates a thoughtful approach to love — you "
         "don't rush, you discern. This intentionality is your greatest "
         "romantic asset. What you choose, you cherish."),
        ("🎶 Harmonious Bonds",
         "Your lines suggest love that arrives through shared experiences — "
         "a trip, a creative project, an unexpected conversation. Stay open "
         "to connections forming in unlikely places."),
    ],
    "gentle": [
        ("🌿 The Independent Spirit",
         "A lighter heart line often belongs to those who love fiercely but "
         "value their own space. A partner who celebrates your independence "
         "rather than challenging it is your perfect match."),
        ("🦋 Love in Bloom",
         "Your romantic story is still unfolding beautifully. The lines "
         "suggest a love that arrives when you've stopped searching and "
         "started simply living fully."),
    ],
    "faint": [
        ("🌙 The Patient Heart",
         "Subtler lines in this region speak of a love life that deepens "
         "quietly and lastingly. You are not built for quick connections — "
         "you are built for the kind that endures."),
    ],
}

SUCCESS = {
    "strong": [
        ("✨ Destiny Line Blazing",
         "A prominent fate line running true to Saturn's mount is the "
         "classical indicator of someone whose success feels inevitable — "
         "not luck, but alignment between effort and purpose. Major "
         "milestones are accelerating toward you."),
        ("🏆 The Apex Achiever",
         "Multiple strong convergent lines create a pattern ancient readers "
         "called the 'star of achievement'. Public recognition, material "
         "abundance, and the satisfaction of meaningful impact all feature "
         "strongly in your near future."),
        ("🌠 The Unstoppable",
         "Your palm's overall line density and depth score places you in the "
         "highest tier of life-force expression. Success here is not a "
         "destination but a constant companion — the question is only which "
         "arena you choose to illuminate first."),
    ],
    "moderate": [
        ("🎯 The Consistent Victor",
         "Steady lines build steady wins. Your path to success is paved with "
         "deliberate choices and compounding small victories. The world rewards "
         "your kind of sustained excellence — perhaps not loudly at first, "
         "but profoundly in the long run."),
        ("🌱 Seeds of Greatness",
         "Your palm shows the pattern of someone whose most significant "
         "success arrives in the second half of their journey. Everything "
         "before this moment has been preparation. The harvest approaches."),
        ("⚖️ The Balanced Achiever",
         "Your lines suggest success in multiple domains simultaneously — "
         "career, relationships, creative pursuits. You are not built to "
         "excel in one lane only. Your greatest wins will be holistic."),
    ],
    "gentle": [
        ("🌸 The Quiet Triumph",
         "Lighter success markers often belong to those who redefine the "
         "word. Your success will look different from convention — more "
         "meaningful, more personal, more yours. And that is its truest form."),
        ("🦋 Metamorphosis Imminent",
         "A gentler pattern now does not predict a gentle outcome — it "
         "predicts transformation. You are in the chrysalis phase. What "
         "emerges will surprise even you."),
    ],
    "faint": [
        ("🌙 The Quiet Power",
         "The most powerful rivers run deepest and quietest. Understated "
         "lines can mask extraordinary inner resources. Your success will "
         "arrive not with fanfare but with undeniable weight."),
    ],
}

# ── Planetary influence flavour ────────────────────────────────────────────────

PLANET_FLAVOUR = {
    "Jupiter":  ("expansion, wisdom, and good fortune", "🪐"),
    "Saturn":   ("discipline, mastery, and karmic reward", "⭐"),
    "Venus":    ("love, beauty, and creative abundance", "💫"),
    "Mars":     ("courage, drive, and passionate action", "🔴"),
    "Mercury":  ("communication, intellect, and swift change", "✨"),
    "Moon":     ("intuition, emotion, and deep inner knowing", "🌙"),
    "Sun":      ("vitality, identity, and radiant purpose", "☀️"),
}

# ── Lucky symbols / closing flourishes ────────────────────────────────────────

CLOSING_BLESSINGS = [
    "The stars align in your favour this season. 🌟",
    "Trust the timing of your life — all is unfolding precisely. ✨",
    "Your highest chapter has not yet been written. 📖",
    "What you seek is also seeking you. 🔮",
    "The universe conspires on behalf of those who persist. 💫",
    "Your palm holds ancient wisdom — your hands will write new history. 🙌",
    "Fortune favours the bold, and boldness is written into your lines. ⚡",
]

LUCKY_NUMBERS_POOL  = list(range(1, 100))
LUCKY_COLOURS       = ["Deep Indigo","Midnight Gold","Forest Jade","Crimson Rose",
                        "Celestial Blue","Amber Dusk","Silver Mist","Coral Dawn",
                        "Obsidian Black","Ivory Pearl","Sage Green","Ruby Red"]
LUCKY_GEMS          = ["Amethyst","Citrine","Lapis Lazuli","Rose Quartz",
                        "Emerald","Sapphire","Tiger's Eye","Moonstone",
                        "Carnelian","Aquamarine","Black Tourmaline","Garnet"]
BEST_DAYS           = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
POWER_HOURS         = ["6–8 AM","9–11 AM","12–2 PM","3–5 PM","7–9 PM","10 PM–12 AM"]


# ── Scoring engine ─────────────────────────────────────────────────────────────

def _score_line(feat: dict, palm_w: int) -> float:
    """
    Normalise a line's overall 'presence' to a [0,1] score.
    Combines segment count, total length (relative to palm width), and
    inverse curvature (straight = reliable, curved = expressive).
    """
    if not feat or feat.get("segment_count", 0) == 0:
        return 0.0

    seg  = min(feat["segment_count"], 12) / 12.0
    rel  = min(feat["total_length_px"] / max(palm_w, 1), 3.0) / 3.0
    curv = feat.get("curvature_deg", 0)
    curv_norm = max(0.0, 1.0 - curv / 90.0)  # low curvature → high score

    return round(0.35 * seg + 0.45 * rel + 0.20 * curv_norm, 4)


def _tier(score: float) -> str:
    if score >= 0.55: return "strong"
    if score >= 0.35: return "moderate"
    if score >= 0.15: return "gentle"
    return "faint"


def _pick(bank: dict, tier: str, rng: random.Random) -> tuple:
    candidates = bank.get(tier, bank.get("gentle", [("Unknown","")]))
    return rng.choice(candidates)


# ── Star sign from palm geometry ───────────────────────────────────────────────

def _derive_sign(features: list, palm_w: int, palm_h: int) -> str:
    """
    Whimsically derive an astrological sign from palm geometry.
    Purely for entertainment — maps combined line scores to zodiac wheel.
    """
    signs = ["Aries ♈","Taurus ♉","Gemini ♊","Cancer ♋",
             "Leo ♌","Virgo ♍","Libra ♎","Scorpio ♏",
             "Sagittarius ♐","Capricorn ♑","Aquarius ♒","Pisces ♓"]
    total = sum(_score_line(f, palm_w) for f in features)
    ratio = (palm_h / max(palm_w, 1))
    idx   = int((total * 3.7 + ratio * 1.9) * 100) % 12
    return signs[idx]


# ── Main public function ───────────────────────────────────────────────────────

def generate_oracle_reading(features: list, palm_w: int, palm_h: int) -> dict:
    """
    Generate a full palm oracle reading from extracted CV features.

    Parameters
    ----------
    features : list of feature dicts from feature_analysis.analyse_all_lines()
    palm_w   : palm ROI width  in pixels
    palm_h   : palm ROI height in pixels

    Returns
    -------
    dict with keys: career, health, marriage, success, meta
    Each domain dict has: title, reading, score, tier, stars (1–5)
    meta has:  zodiac_sign, ruling_planet, lucky_number, lucky_colour,
               lucky_gem, best_day, power_hour, closing_blessing
    """

    # Build a lookup by line name
    feat_map = {f["name"]: f for f in features}
    heart = feat_map.get("Heart Line", {})
    head  = feat_map.get("Head Line",  {})
    life  = feat_map.get("Life Line",  {})

    # Overall geometric "seed" for deterministic but image-specific randomness
    seed = int(
        _score_line(heart, palm_w) * 10000
        + _score_line(head,  palm_w) * 1000
        + _score_line(life,  palm_w) * 100
        + palm_w + palm_h
    )
    rng = _rng(seed)

    # ── Per-domain scores ──────────────────────────────────────────────────────
    # Career  ← heart line + head line (ambition + intellect)
    career_score = round(0.55 * _score_line(heart, palm_w)
                        + 0.45 * _score_line(head,  palm_w), 4)

    # Health  ← life line (primary) + head line (mental health)
    health_score = round(0.70 * _score_line(life,  palm_w)
                        + 0.30 * _score_line(head,  palm_w), 4)

    # Marriage ← heart line (primary) + life line (stability)
    marriage_score = round(0.75 * _score_line(heart, palm_w)
                          + 0.25 * _score_line(life,  palm_w), 4)

    # Success ← all three lines equally
    success_score = round(
        (_score_line(heart, palm_w)
         + _score_line(head,  palm_w)
         + _score_line(life,  palm_w)) / 3.0, 4)

    def stars(score):
        return max(1, min(5, round(1 + score * 4)))

    def make_domain(score, bank):
        tier  = _tier(score)
        title, reading = _pick(bank, tier, rng)
        return {
            "title":   title,
            "reading": reading,
            "score":   score,
            "tier":    tier,
            "stars":   stars(score),
        }

    career  = make_domain(career_score,  CAREER)
    health  = make_domain(health_score,  HEALTH)
    marriage = make_domain(marriage_score, MARRIAGE)
    success  = make_domain(success_score,  SUCCESS)

    # ── Planet ruling ──────────────────────────────────────────────────────────
    planet_name = rng.choice(list(PLANET_FLAVOUR.keys()))
    planet_meaning, planet_symbol = PLANET_FLAVOUR[planet_name]

    # ── Lucky attributes ───────────────────────────────────────────────────────
    lucky_nums = sorted(rng.sample(LUCKY_NUMBERS_POOL, 3))
    lucky_col  = rng.choice(LUCKY_COLOURS)
    lucky_gem  = rng.choice(LUCKY_GEMS)
    best_day   = rng.choice(BEST_DAYS)
    power_hour = rng.choice(POWER_HOURS)
    blessing   = rng.choice(CLOSING_BLESSINGS)
    zodiac     = _derive_sign(features, palm_w, palm_h)

    return {
        "career":   career,
        "health":   health,
        "marriage": marriage,
        "success":  success,
        "meta": {
            "zodiac_sign":    zodiac,
            "ruling_planet":  planet_name,
            "planet_symbol":  planet_symbol,
            "planet_meaning": planet_meaning,
            "lucky_numbers":  lucky_nums,
            "lucky_colour":   lucky_col,
            "lucky_gem":      lucky_gem,
            "best_day":       best_day,
            "power_hour":     power_hour,
            "closing_blessing": blessing,
        },
        "disclaimer": (
            "✨ FOR ENTERTAINMENT ONLY ✨  This reading is the digital "
            "equivalent of a horoscope — it is generated from geometric "
            "measurements of palm line images using rule-based thresholds. "
            "It has no scientific basis and should not be used to make any "
            "real decisions about career, health, relationships, or life. "
            "Please consult qualified professionals for actual advice."
        ),
    }
