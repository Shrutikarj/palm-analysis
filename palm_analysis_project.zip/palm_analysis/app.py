"""
app.py  -  PalmCV Flask Backend
Routes: GET / | POST /analyse | GET /demo | GET /health
"""
import os, uuid, traceback, warnings, json
warnings.filterwarnings("ignore")
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import cv2
import numpy as np
from flask import Flask, request, render_template, Response
from werkzeug.utils import secure_filename

from hand_detection   import detect_landmarks
from palm_extraction  import extract_palm_roi, preprocess_palm
from line_detection   import (detect_edges, detect_lines_hough,
                               classify_palm_lines, draw_classified_lines)
from feature_analysis import analyse_all_lines, build_summary
from palm_oracle      import generate_oracle_reading

app = Flask(__name__)
UPLOAD_FOLDER = os.path.join("static", "uploads")
RESULT_FOLDER = os.path.join("static", "results")
ALLOWED_EXT   = {"png","jpg","jpeg","webp","bmp"}
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

class _NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer): return int(obj)
        if isinstance(obj, np.floating): return float(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return super().default(obj)

def jresp(data, status=200):
    return Response(json.dumps(data, cls=_NpEncoder),
                    status=status, mimetype="application/json")

def allowed(fn):
    return "." in fn and fn.rsplit(".",1)[1].lower() in ALLOWED_EXT

def save_img(img, folder, name):
    p = os.path.join(folder, name)
    cv2.imwrite(p, img)
    return p.replace("\\", "/")

def resize_img(img, mx=800):
    h, w = img.shape[:2]
    if max(h,w) <= mx: return img
    s = mx / max(h,w)
    return cv2.resize(img,(int(w*s),int(h*s)),interpolation=cv2.INTER_AREA)

def gray3(g):
    return cv2.merge([g,g,g])

def run_pipeline(image, uid):
    image  = resize_img(image)
    orig_p = save_img(image, UPLOAD_FOLDER, uid+"_original.jpg")
    det    = detect_landmarks(image)
    if not det["success"]:
        return {"success":False,"error":
            "No hand detected.\n- Use a well-lit photo\n- Palm flat, facing camera\n- Avoid cluttered backgrounds"}
    lm_p = save_img(det["annotated_image"], RESULT_FOLDER, uid+"_landmarks.jpg")
    pd   = extract_palm_roi(image, det["landmarks"])
    if not pd["success"]:
        return {"success":False,"error":"Could not extract palm region."}
    roi_p  = save_img(pd["palm_roi"],   RESULT_FOLDER, uid+"_palm_roi.jpg")
    mask_p = save_img(pd["mask_image"], RESULT_FOLDER, uid+"_mask.jpg")
    prep   = preprocess_palm(pd["palm_roi"])
    save_img(gray3(prep["gray"]),      RESULT_FOLDER, uid+"_gray.jpg")
    save_img(gray3(prep["equalized"]), RESULT_FOLDER, uid+"_equalized.jpg")
    prep_p = save_img(gray3(prep["blurred"]), RESULT_FOLDER, uid+"_preprocessed.jpg")
    thr_p  = save_img(gray3(prep["thresh"]),  RESULT_FOLDER, uid+"_threshold.jpg")
    edges  = detect_edges(prep["blurred"])
    edge_p = save_img(gray3(edges), RESULT_FOLDER, uid+"_edges.jpg")
    hough  = detect_lines_hough(edges, pd["palm_roi"])
    hgh_p  = save_img(hough["line_image"], RESULT_FOLDER, uid+"_hough_lines.jpg")
    ph, pw = pd["palm_roi"].shape[:2]
    cls    = classify_palm_lines(hough["lines"], ph, pw)
    ci     = draw_classified_lines(pd["palm_roi"], cls)
    cls_p  = save_img(ci, RESULT_FOLDER, uid+"_classified.jpg")
    feats  = analyse_all_lines(cls, ph, pw)
    oracle = generate_oracle_reading(feats, pw, ph)
    return {
        "success":True, "error":None,
        "images":{
            "original":orig_p, "landmarks":lm_p, "palm_roi":roi_p,
            "mask":mask_p, "preprocessed":prep_p, "threshold":thr_p,
            "edges":edge_p, "hough_lines":hgh_p, "classified":cls_p,
        },
        "stats":{
            "total_lines_detected":hough["count"],
            "palm_width_px":pw, "palm_height_px":ph,
            "detection_confidence":round(float(det.get("confidence",0)),3),
        },
        "features":feats, "summary":build_summary(feats),
        "oracle": oracle,
    }

def _prebuild_demo():
    demo_src = os.path.join(UPLOAD_FOLDER, "demo_hand.jpg")
    demo_out = os.path.join(RESULT_FOLDER,  "demo_classified.jpg")
    if not os.path.exists(demo_src) or os.path.exists(demo_out): return
    from tflite_hand_detector import _draw_hand_skeleton
    img = cv2.imread(demo_src)
    if img is None: return
    lm = [(320,382),(240,322),(220,272),(210,237),(205,202),
          (250,177),(253,137),(255,107),(256, 90),(305,167),
          (307,124),(308, 94),(309, 80),(355,172),(358,129),
          (360, 99),(361, 86),(393,192),(398,160),(401,137),(403,124)]
    save_img(img, UPLOAD_FOLDER, "demo_original.jpg")
    ann = img.copy(); _draw_hand_skeleton(ann, lm)
    save_img(ann, RESULT_FOLDER, "demo_landmarks.jpg")
    pd = extract_palm_roi(img, lm)
    save_img(pd["palm_roi"],   RESULT_FOLDER, "demo_palm_roi.jpg")
    save_img(pd["mask_image"], RESULT_FOLDER, "demo_mask.jpg")
    prep = preprocess_palm(pd["palm_roi"])
    save_img(gray3(prep["blurred"]), RESULT_FOLDER, "demo_preprocessed.jpg")
    save_img(gray3(prep["thresh"]),  RESULT_FOLDER, "demo_threshold.jpg")
    edges = detect_edges(prep["blurred"])
    save_img(gray3(edges), RESULT_FOLDER, "demo_edges.jpg")
    hough = detect_lines_hough(edges, pd["palm_roi"])
    save_img(hough["line_image"], RESULT_FOLDER, "demo_hough_lines.jpg")
    ph, pw = pd["palm_roi"].shape[:2]
    cls = classify_palm_lines(hough["lines"], ph, pw)
    save_img(draw_classified_lines(pd["palm_roi"],cls), RESULT_FOLDER,"demo_classified.jpg")

_prebuild_demo()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/health")
def health():
    return jresp({"status":"ok"})

@app.route("/analyse", methods=["POST"])
def analyse():
    try:
        if "image" not in request.files:
            return jresp({"success":False,"error":"No image field in request."},400)
        f = request.files["image"]
        if not f.filename or not allowed(f.filename):
            return jresp({"success":False,"error":"Unsupported file type."},400)
        buf = np.frombuffer(f.read(), dtype=np.uint8)
        img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        if img is None:
            return jresp({"success":False,"error":"Could not decode image."},400)
        return jresp(run_pipeline(img, uuid.uuid4().hex[:10]))
    except Exception:
        traceback.print_exc()
        return jresp({"success":False,"error":"Internal server error."},500)

@app.route("/demo")
def demo():
    try:
        roi_path = os.path.join(RESULT_FOLDER, "demo_palm_roi.jpg")
        if not os.path.exists(roi_path): _prebuild_demo()
        roi = cv2.imread(roi_path)
        if roi is None:
            return jresp({"success":False,"error":"Demo assets missing - run setup.py"},404)
        prep  = preprocess_palm(roi)
        edges = detect_edges(prep["blurred"])
        hough = detect_lines_hough(edges, roi)
        ph, pw = roi.shape[:2]
        cls   = classify_palm_lines(hough["lines"], ph, pw)
        feats = analyse_all_lines(cls, ph, pw)
        oracle = generate_oracle_reading(feats, pw, ph)
        R = "static/results/demo_{}.jpg"
        U = "static/uploads/demo_{}.jpg"
        return jresp({
            "success":True, "error":None,
            "images":{
                "original":U.format("original"), "landmarks":R.format("landmarks"),
                "palm_roi":R.format("palm_roi"),  "mask":R.format("mask"),
                "preprocessed":R.format("preprocessed"), "threshold":R.format("threshold"),
                "edges":R.format("edges"), "hough_lines":R.format("hough_lines"),
                "classified":R.format("classified"),
            },
            "stats":{
                "total_lines_detected":hough["count"],
                "palm_width_px":pw, "palm_height_px":ph,
                "detection_confidence":0.97,
            },
            "features":feats, "summary":build_summary(feats),
            "oracle": oracle,
        })
    except Exception:
        traceback.print_exc()
        return jresp({"success":False,"error":"Internal server error."},500)

if __name__ == "__main__":
    print("\n" + "="*55)
    print("  PalmCV  -  http://127.0.0.1:5000")
    print("="*55 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
